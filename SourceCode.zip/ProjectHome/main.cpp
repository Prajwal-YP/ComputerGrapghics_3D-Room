#include<GL/glu.h>
#include<GL/glut.h>
#include<windows.h>

GLfloat T=0;
GLfloat Pos[4]={0,0,2,1};
GLfloat Col[4]={1,1,1,1};
GLfloat Col1[4]={1,0,0,1};
GLfloat Col2[4]={1,1,0,1};
GLfloat Col3[4]={1,0,1,1};
GLfloat Col4[4]={1,.09,0,1};
GLfloat Col5[4]={0,0,1,1};
GLfloat Col6[4]={0,1,0,1};
GLfloat Col7[4]={.241,.235,.156,1};
float Z=5,S=0,s=0,D=0;
int ld=1,rd=-1,x=0,y=0,z=0;

void Spin()
{
    if(s==360)
        s=1;
    S+=s;
    D+=0.3;
    glutPostRedisplay();
}

void key(unsigned char ch,int x1,int y1)
{
    switch(ch)
    {
        case 'o': ld=3;rd=-3; break;
        case 'c': ld=1;rd=-1; break;
        case 'd': x=0;y=0;z=0;T = 0; break;
        case 'r': x=0;y=1;z=0;T -= 1; break;
        case 'l': x=0;y=1;z=0;T += 1; break;
        case 't': x=1;y=0;z=0;T += 1; break;
        case 'b': x=1;y=0;z=0;T -= 1; break;
        case 'z': Z+=.5; break;
        case 'Z': Z-=.5; break;
        case 'q': exit(0); break;
        case 'S':
            if(s<0.8)
                s+=.2;
            break;
        case 's':
            if(s>0)
                s-=.1;
            break;
    }
    glutPostRedisplay();
}

void cup()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
        glTranslatef(0,.2,0);
        glScalef(0.9,0.9,0.9);
        glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col5);
        glLightfv(GL_LIGHT0,GL_AMBIENT_AND_DIFFUSE,Col5);
            glPushMatrix();
            glTranslatef(0.13,0,0);
            glScalef(0.05,0.3,0.3);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(-0.13,0,0);
            glScalef(0.05,0.3,0.3);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0,-0.13,0);
            glScalef(0.3,0.05,0.3);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0,0,-0.13);
            glScalef(0.3,0.3,0.05);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0,0,0.13);
            glScalef(0.3,0.3,0.05);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0.33,0,0);
            glScalef(0.02,0.2,0.2);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0.24,0.1,0);
            glScalef(0.2,0.02,0.2);
            glutSolidCube(1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(0.24,-0.1,0);
            glScalef(0.2,0.02,0.2);
            glutSolidCube(1);
            glPopMatrix();

        glPopAttrib();
}

void table()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
        glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col2);
        glTranslatef(0,-.6,0);

            glPushMatrix();
            glTranslatef(-.45,-.48,-.4);
            glScalef(1,10,1);
            glutSolidCube(.1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(.45,-.48,-.4);
            glScalef(1,10,1);
            glutSolidCube(.1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(-.45,-.48,.4);
            glScalef(1,10,1);
            glutSolidCube(.1);
            glPopMatrix();

            glPushMatrix();
            glTranslatef(.45,-.48,.4);
            glScalef(1,10,1);
            glutSolidCube(.1);
            glPopMatrix();

            glPushMatrix();
            glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col3);
            glTranslatef(0,0,0);
            glScalef(10,1,10);
            glutSolidCube(.1);
            glPopMatrix();

        glPopAttrib();
}

void teapot()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
        glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col2);
        glLightfv(GL_LIGHT0,GL_DIFFUSE,Col2);
        glPushMatrix();
        glTranslatef(-.35,0.05,0);
        glRotatef(-45,0,0,1);
        glScalef(1.3,1.3,1.3);
        glutSolidTeapot(.2);
        glPopMatrix();
        glPopAttrib();
}

void room()
{
    glRotatef(T,x,y,z);
        glPushMatrix();
        glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,Col1);
        glTranslatef(0,1.6,0);
        glScalef(4,0.2,4);
        glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,Col6);
        glTranslatef(0,-1.5,0);
        glScalef(4,0.2,4);
        glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,Col5);
        glTranslatef(2,0,0);
        glScalef(0.2,3,4);
        glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,Col3);
        glTranslatef(-2,0,0);
        glScalef(0.2,3,4);
        glutSolidCube(1);
        glPopMatrix();

        glPushAttrib(GL_ALL_ATTRIB_BITS);
        glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,Col4);
            glPushMatrix();
            glTranslatef(0,0,-2);
            glScalef(4,3,0.2);
            glutSolidCube(1);
            glPopMatrix();
        glPopAttrib();

        glPushMatrix();
        glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,Col7);
        glTranslatef(ld,0,2);
        glScalef(2,3,0.2);
        glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
        glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,Col7);
        glTranslatef(rd,0,2);
        glScalef(2,3,0.2);
        glutSolidCube(1);
        glPopMatrix();
}

void fan()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,Col1);
    glTranslatef(-.1,1.2,0);
    glRotatef(S,0,1,0);
        glPushMatrix();
            glTranslatef(0,0,0);
            glScalef(1,.1,.1);
            glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0,0,0);
            //glScalef(.5,.1,.1);
            glutSolidSphere(.1,100,100);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0,0,0);
            glScalef(.1,.1,1);
            glutSolidCube(1);
        glPopMatrix();

        glPushMatrix();
            glTranslatef(0,0.2,0);
            glScalef(.1,0.5,.1);
            glutSolidCube(1);
        glPopMatrix();

    glPopAttrib();
}

void decoration()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col6);
    glTranslatef(-0.3,0.47,0);

        glPushMatrix();
        glTranslatef(1.4,1,-1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-1.4,1,-1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(1.4,-1,-1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-1.4,-1,-1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(1.4,1,1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-1.4,1,1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(1.4,-1,1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-1.4,-1,1.5);
        glScalef(0.16,0.16,0.16);
        glRotatef(D,1,1,1);
            glutSolidDodecahedron();
        glPopMatrix();

    glPopAttrib();
}

void fandeco()
{
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE,Col2);
        glPushMatrix();
            glScalef(0.07,0.07,0.07);
            glutSolidDodecahedron();
        glPopMatrix();

    glPopAttrib();
}

void Draw()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();

    glLightfv(GL_LIGHT0,GL_POSITION,Pos);
    glLightfv(GL_LIGHT0,GL_DIFFUSE,Col);
    gluLookAt(0,0,Z,0,0,0,0,1,0);

    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glScalef(0.8,0.8,0.8);
        room();
        teapot();
        table();
        cup();
        decoration();
        fan();
        fandeco();
    glPopAttrib();

    glutSwapBuffers();
}

void myInit()
{
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-1,1,-1,1,1,15);
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
}

int main(int c,char **v)
{
    glutInit(&c,v);
    glutInitWindowSize(500,500);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("3-D Room");
    myInit();
    glutDisplayFunc(Draw);
    glutIdleFunc(Spin);
    glutKeyboardFunc(key);


    glutMainLoop();
    return 0;
}
